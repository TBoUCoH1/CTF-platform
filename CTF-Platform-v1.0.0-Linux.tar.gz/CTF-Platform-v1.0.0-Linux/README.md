# 🎯 CTF Platform v1.0.0

Capture The Flag Training Platform - Desktop Application for Linux

## 📋 System Requirements

- **OS**: Ubuntu 20.04+, Debian 11+, or compatible
- **RAM**: 2GB minimum
- **Disk**: 1GB free space
- **Docker**: Required (will be installed automatically)

## 🚀 Installation

### Quick Install:
./install.sh

### Manual Steps:
1. Extract the archive
2. Run: `./install.sh`
3. Log out and log back in
4. Launch from Applications menu

## 📖 Usage

### Launch Application:
- **From menu**: Search for "CTF Platform"
- **From terminal**: `ctf-platform`

### Manual Control:

**Start backend:**
./start-backend.sh

**Stop backend:**
./stop-backend.sh

**Frontend only:**
./CTFApp

## 🔧 Troubleshooting

### Backend won't start:
cd ~/.local/share/ctf-platform
docker-compose logs

### Permission denied:
sudo usermod -aG docker $USER

Then log out and log back in

### Port already in use:
sudo netstat -tulpn | grep -E '5000|8080|5432'


## 📝 Features

✅ 21 CTF challenges (Web, Crypto, Forensics, etc.)  
✅ Real-time leaderboard  
✅ Progress tracking  
✅ Hint system  
✅ Dark theme UI  

## 🌐 Default Ports

- Frontend: Qt Desktop App
- Backend API: http://localhost:8080
- Web Interface: http://localhost:5000
- Database: localhost:5432

## 📧 Support

For issues and questions, visit our GitHub repository.

---
Made with ❤️ for CTF enthusiasts
